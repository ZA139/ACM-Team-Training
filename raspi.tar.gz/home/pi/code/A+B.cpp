#include<cstdio>
long long x,y;
int main(void){
	while(~scanf("%lld%lld",&x,&y))
	{
		printf("%lld\n",x+y);
	}
	return 0;
}
