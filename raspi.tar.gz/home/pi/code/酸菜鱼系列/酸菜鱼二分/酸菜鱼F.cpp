#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
using namespace std;
int main(void){
	return 0;
}
