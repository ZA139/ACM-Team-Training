#include<cstirng>
#include<cstdio>

int main(void)
{
	int t;
	scanf("%d",&t);
	while(t){
	}
