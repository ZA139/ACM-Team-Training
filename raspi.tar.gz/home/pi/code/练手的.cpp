#include<cstdio>
#include<algorithm>
#include<cstring>
#include<iostream>
#include<ctime>
#include<cstdlib>
#include<fstream>
#include<iomanip>
using namespace std;
typedef BigNumber{
	char nums[600];
	const operator + (const BigNumber& B)
int main(void){
	return 0;
}
