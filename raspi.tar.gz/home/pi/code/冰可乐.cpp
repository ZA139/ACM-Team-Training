#include<cstdio>
int main(void){
	int S,N,M;
	scanf("%d%d%d",&S.&N,&M);
	while(S&&N&&M){
		if(S%2==0||((N>=S/2)&&(M>=S/2))
			printf("NO");
		
		scanf("%d%d%d",&S.&N,&M);
	}
