#include<cstdio>
using namespace std;
bool check(long long a){

	}
int main(void)
{
	
	return 0;
}
